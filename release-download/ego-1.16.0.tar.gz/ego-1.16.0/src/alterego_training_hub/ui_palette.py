"""Command palette and quick file open — the Ctrl+P / Ctrl+Shift+P experience."""
from __future__ import annotations

import tkinter as tk
from collections.abc import Callable
from pathlib import Path
from typing import Any

from .i18n import t
from .ui_common import F_BASE, F_MONO, C
from .ui_editor import list_workspace_files

MAX_ITEMS = 400


def _fuzzy(query: str, label: str) -> bool:
    """Every whitespace-separated token of the query must appear in the label."""
    query = query.strip().lower()
    if not query:
        return True
    target = label.lower()
    return all(token in target for token in query.split())


class CommandPalette(tk.Toplevel):
    """Modal list with a filter box: commands or workspace files."""

    def __init__(self, app, mode: str = "commands"):
        super().__init__(app)
        self.app = app
        self.mode = mode
        self._items: list[tuple[str, Callable[[], Any] | Path]] = []
        self._filtered: list[int] = []
        title = t(t('Быстрое открытие (Ctrl+P)')) if mode == "files" else \
            t(t('Палитра команд (Ctrl+Shift+P)'))
        try:
            self.title(title)
            self.transient(app)
            self.geometry("680x420")
            self.grab_set()
        except Exception:
            pass
        self.configure(bg=C["bg"])

        tk.Label(self, text=title, bg=C["bg"], fg=C["muted"], font=F_BASE,
                 anchor="w", padx=12, pady=(10, 2)).pack(fill="x")
        self.query = tk.Entry(self, bd=1, relief="solid", font=F_MONO)
        self.query.pack(fill="x", padx=12, pady=6)
        self.listbox = tk.Listbox(self, bd=1, relief="solid", font=F_MONO,
                                  activestyle="none")
        self.listbox.pack(fill="both", expand=True, padx=12, pady=(0, 10))

        self.query.bind("<KeyRelease>", lambda _e: self.refresh())
        self.query.bind("<Return>", lambda _e: self.run_selected())
        self.query.bind("<Down>", lambda _e: self._move(1))
        self.query.bind("<Up>", lambda _e: self._move(-1))
        self.listbox.bind("<Double-1>", lambda _e: self.run_selected())
        self.bind("<Escape>", lambda _e: self.close())

        self._build_items()
        self.refresh()
        try:
            self.query.focus_set()
        except Exception:
            pass

    # ---------------------------------------------------------------- items
    def _build_items(self):
        app = self.app
        if self.mode == "files":
            root = app.workspace_root()
            if root is not None:
                for path in list_workspace_files(root, limit=MAX_ITEMS):
                    try:
                        label = str(path.relative_to(root))
                    except ValueError:
                        label = str(path)
                    self._items.append((label, path))
            else:
                self._items.append((t(t('Рабочая папка не выбрана')), None))
            return

        commands: list[tuple[str, Callable[[], Any]]] = [
            (t(t('Перейти: Редактор кода')), lambda: app.show_page("editor")),
            (t(t('Перейти: Рабочая папка')), lambda: app.show_page("workspace")),
            (t(t('Перейти: Поиск по проекту')), lambda: app.show_page("search")),
            (t(t('Перейти: Модели')), lambda: app.show_page("models")),
            (t(t('Перейти: Датасеты')), lambda: app.show_page("datasets")),
            (t(t('Перейти: Модель и прогресс')), lambda: app.show_page("model")),
            (t(t('Перейти: Playground')), lambda: app.show_page("playground")),
            (t(t('Перейти: Обучение')), lambda: app.show_page("training")),
            (t(t('Перейти: Внешние GPU')), lambda: app.show_page("gpu")),
            (t(t('Перейти: Серверы')), lambda: app.show_page("servers")),
            (t(t('Перейти: Коннекторы')), lambda: app.show_page("connectors")),
            (t(t('Перейти: Настройки')), lambda: app.show_page("settings")),
            (t(t('Чат: фокус в поле ввода')), lambda: app.show_page("chat")),
            (t(t('Панель: терминал / проблемы')), lambda: app.show_bottom("terminal")),
            (t(t('Проблемы: открыть и обновить')),
             lambda: app.show_bottom("problems")),
            (t(t('Панель: свернуть/развернуть (Ctrl+J)')), app.toggle_bottom),
            (t(t('Страница: обновить (F5)')), app.refresh_current),
            (t(t('Редактор: сохранить файл')), lambda: app.pages["editor"].save_file()),
            (t(t('Редактор: закрыть вкладку')), lambda: app.pages["editor"].close_tab()),
            (t(t('Редактор: поиск (Ctrl+F)')), lambda: app.pages["editor"].open_find()),
            (t(t('Редактор: заменить (Ctrl+H)')),
             lambda: app.pages["editor"].open_find(replace=True)),
            (t(t('Редактор: перейти к строке (Ctrl+G)')),
             lambda: app.pages["editor"].open_goto_line()),
            (t(t('Редактор: форматировать файл')),
             lambda: app.pages["editor"].format_file()),
            (t(t('Редактор: разделённый вид (Ctrl+\\)')),
             lambda: app.pages["editor"].toggle_split()),
            (t(t('Редактор: проверить файл (линт)')),
             lambda: app.pages["editor"].run_lint()),
            (t(t('Масштаб: увеличить шрифт (Ctrl+)')),
             lambda: app.pages["editor"].zoom_in()),
            (t(t('Масштаб: уменьшить шрифт (Ctrl-)')),
             lambda: app.pages["editor"].zoom_out()),
            (t(t('Закладка: переключить (Ctrl+F2)')),
             lambda: app.pages["editor"].toggle_bookmark()),
            (t(t('Git: открыть исходный контроль (Ctrl+Shift+G)')),
             lambda: app.show_bottom("git")),
            (t(t('Git: обновить статус')), lambda: app.git_panel.refresh()),
            (t(t('Тема: переключить светлая/тёмная')),
             lambda: app.toggle_theme()),
            (t(t('Диагностика: запустить проверку')),
             lambda: app.pages["settings"].run_check()),
            (t(t('Обучение: запустить')), lambda: app.pages["training"].start_training()),
            (t(t('Обучение: остановить')), lambda: app.pages["training"].stop_training()),
            (t(t('Чат: мысли агента')), lambda: app.chat_panel.show_thoughts()),
            (t(t('Чат: что агент сделал')), lambda: app.chat_panel.show_actions()),
            (t(t('Чат: контекст модели')), lambda: app.chat_panel.show_context()),
            (t(t('Чат: проверить ответ (критик)')),
             lambda: app.chat_panel.run_critique_last()),
            (t(t('Модель: мастер «Своя ЛЛМ» — план')),
             lambda: app.pages["model"].show_wizard_plan()),
            (t(t('Модель: сэмплы генерации')),
             lambda: app.pages["model"].show_samples()),
            (t(t('Модель: сравнить до/после')),
             lambda: app.pages["model"].show_before_after()),
            (t(t('Сайдбар: свернуть в иконки (activity bar)')),
             lambda: app.toggle_sidebar_compact()),
        ]
        self._items.extend(commands)

    def refresh(self):
        try:
            query = self.query.get()
        except Exception:
            query = ""
        self.listbox.delete(0, "end")
        self._filtered = []
        for index, (label, _target) in enumerate(self._items):
            if _fuzzy(query, label):
                self.listbox.insert("end", label)
                self._filtered.append(index)
        if self._filtered:
            try:
                self.listbox.selection_set(0)
                self.listbox.activate(0)
            except Exception:
                pass

    def _move(self, step: int):
        try:
            size = self.listbox.size()
            if not size:
                return
            current = (self.listbox.curselection() or (0,))[0]
            self.listbox.selection_clear(0, "end")
            target = (current + step) % size
            self.listbox.selection_set(target)
            self.listbox.activate(target)
        except Exception:
            pass

    def run_selected(self):
        try:
            selection = self.listbox.curselection()
        except Exception:
            selection = ()
        position = selection[0] if selection else 0
        if not self._filtered or position >= len(self._filtered):
            self.close()
            return
        _label, target = self._items[self._filtered[position]]
        self.close()
        if self.mode == "files":
            if isinstance(target, Path):
                self.app.show_page("editor")
                self.app.pages["editor"].open_file(target)
        elif callable(target):
            target()

    def close(self):
        try:
            self.destroy()
        except Exception:
            pass


def open_command_palette(app, mode: str = "commands") -> CommandPalette:
    return CommandPalette(app, mode)
